var AWS = require('aws-sdk');
var sns = new AWS.SNS();

var SNSTopic = process.env.sns;

console.log('Loading SNS');

exports.main = async (event, context, callback) => {
  var responseCode = 200;
  var phoneNumber = "";

  var responseBody = {
    message: "Failed to  subscribe to SMS Service (SNS)",
    input: event
  }

  if (event.queryStringParameters && event.queryStringParameters.phoneNumber) {
    console.log("Received phone number: " + event.queryStringParameters.phoneNumber);
    phoneNumber = event.queryStringParameters.phoneNumber;

    console.log('Received event:', JSON.stringify(event, null, 2));

    var params = {
      Protocol: 'sms',
      TopicArn: SNSTopic,
      Endpoint: phoneNumber
    };
    sns.subscribe(params, function(err, data) {
      if (err){
        console.log(err, err.stack); // an error occurred
      } 
      else{
        console.log(data);           // successful response
      }     
    });

    responseBody = {
      message: "Successfully subscribed to SMS Service (SNS)",
      input: event
    }
  }


  // Lambda proxy integration output
  var response = {
    statusCode: responseCode,
    body: JSON.stringify(responseBody)
  };
  console.log("response: " + JSON.stringify(response));
  return response;
};